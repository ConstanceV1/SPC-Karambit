# Karambit v2 candidate verification — 2026-10-01

All installer write tests used a disposable fixture under Distribution\test-fixture-v2\TCF. The live game was not modified by these installer tests.

## Current v2 candidate

- Lua payload SHA-256: 9CB53ACCCF43EFD762D6DF53E1C2142DB88650E8C1084B51FAA3096E70A79C6E.
- PowerShell 5.1 parser: zero syntax errors in Karambit.Common.ps1, Install-Karambit.ps1, and Uninstall-Karambit.ps1.
- CheckOnly before installation: exit 2, compatible but installation needed.
- Install from pristine Season 2 EXE: exit 0. EXE SHA-256 became A5098B8A1A8178BB84A8E131F8F71D39C3D32B496F4407392533DF82386CA08A; installed Lua hash matched the new candidate; manifest PackageId was KarambitPort-S2-20261001.
- Second install: exit 0, reported managed/installed and created no additional backup folder.
- Uninstall: exit 0; EXE SHA-256 returned to pristine 8BA99826C15028C40A633AA3491F6FB0C323897405538859F36548346095055C; mods.txt returned byte-for-byte to SHA-256 18362DC44A1B2C860DA49CC5C9925E74ACC869AA6C627A16CE8C2D440F1FE961; owned Lua and manifest were removed.

## Prior installer hardening tests

The unchanged transaction code also passed 2026-09-30 fixture tests for interrupted-install recovery, unsafe manifest-path refusal before writes, modified-Lua preservation, default collision refusal, explicit replacement with exact restoration, unknown-EXE refusal, and mods.txt without a final newline restoring byte-for-byte. Those scenarios have not been rerun with the v2 Lua payload.

## Runtime status

The revised v2 Lua is a candidate grip fix. **Its in-game grip behavior has not yet been visually confirmed.** The prior package showed a default-knife grip regression after packaging. Do not treat this candidate ZIP as runtime-approved until the user verifies drawing, switching, swinging, and grip recovery in game. Another person's launcher/runtime has not been tested.
