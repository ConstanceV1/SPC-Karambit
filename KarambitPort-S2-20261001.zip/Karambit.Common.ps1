﻿Set-StrictMode -Version Latest

function Get-KarambitHash([string]$Path) {
    if (-not [IO.File]::Exists($Path)) { return $null }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function Assert-KarambitHash([string]$Path, [string]$Expected, [string]$Label) {
    $actual = Get-KarambitHash $Path
    if ($actual -ne $Expected.ToUpperInvariant()) {
        throw "$Label has an unexpected SHA-256. Expected $Expected; actual $actual. Path: $Path"
    }
}

function Resolve-KarambitGameRoot([string]$Requested) {
    if (-not [string]::IsNullOrWhiteSpace($Requested)) {
        if (-not (Test-Path -LiteralPath $Requested -PathType Container)) {
            throw "Game root folder does not exist: $Requested"
        }
        return (Resolve-Path -LiteralPath $Requested).ProviderPath
    }
    $candidates = New-Object System.Collections.Generic.List[string]
    $cursor = $PSScriptRoot
    for ($i = 0; $i -lt 4; $i++) {
        foreach ($candidate in @($cursor, (Join-Path $cursor 'TCF'))) {
            if (Test-Path -LiteralPath (Join-Path $candidate 'Prospect\Binaries\Win64\Prospect-Win64-Shipping.exe') -PathType Leaf) {
                $full = (Resolve-Path -LiteralPath $candidate).ProviderPath
                if (-not $candidates.Contains($full)) { $candidates.Add($full) }
            }
        }
        $parent = Split-Path -Parent $cursor
        if ([string]::IsNullOrWhiteSpace($parent) -or $parent -eq $cursor) { break }
        $cursor = $parent
    }
    if ($candidates.Count -eq 1) { return $candidates[0] }
    if ($candidates.Count -gt 1) {
        Write-Host 'More than one nearby game root was found:'
        foreach ($candidate in $candidates) { Write-Host "  $candidate" }
    }
    if ([Console]::IsInputRedirected) {
        throw 'Pass -GameRoot with the folder containing Prospect. Interactive input is unavailable.'
    }
    $answer = Read-Host 'Enter the game root folder (the folder containing Prospect)'
    if ([string]::IsNullOrWhiteSpace($answer)) { throw 'No game root was supplied.' }
    if (-not (Test-Path -LiteralPath $answer -PathType Container)) { throw "Game root folder does not exist: $answer" }
    return (Resolve-Path -LiteralPath $answer).ProviderPath
}

function Test-KarambitGameStopped([string]$Exe) {
    $running = @(Get-CimInstance Win32_Process -Filter "name='Prospect-Win64-Shipping.exe'" -ErrorAction Stop | Where-Object { $_.ExecutablePath -eq $Exe })
    if ($running.Count -gt 0) {
        throw "Close the target Prospect game window before installing or uninstalling the Karambit: $Exe"
    }
}

function Get-KarambitModEntry([string]$ModsPath) {
    if (-not [IO.File]::Exists($ModsPath)) { throw "UE4SS Mods\mods.txt is missing: $ModsPath" }
    $content = [IO.File]::ReadAllText($ModsPath)
    $anyEntries = [Text.RegularExpressions.Regex]::Matches($content, '(?im)^[ \t]*KarambitPort\b[^\r\n]*')
    if ($anyEntries.Count -gt 1) { throw 'UE4SS Mods\mods.txt has multiple KarambitPort entries. Resolve them manually.' }
    $pattern = '(?im)^[ \t]*KarambitPort[ \t]*:[ \t]*([01])[ \t]*\r?$'
    $matches = [Text.RegularExpressions.Regex]::Matches($content, $pattern)
    if ($anyEntries.Count -eq 1 -and $matches.Count -ne 1) {
        throw 'UE4SS Mods\mods.txt has an unsupported KarambitPort entry. Resolve it manually.'
    }
    if ($matches.Count -gt 1) { throw 'UE4SS Mods\mods.txt has multiple KarambitPort entries. Resolve them manually.' }
    if ($matches.Count -eq 0) { return [pscustomobject]@{ State='absent'; Text=$content; Match=$null } }
    $state = if ($matches[0].Groups[1].Value -eq '1') { 'enabled' } else { 'disabled' }
    return [pscustomobject]@{ State=$state; Text=$content; Match=$matches[0] }
}

function Set-KarambitModEntry([string]$ModsPath, [string]$Action, [string]$OriginalLine, [bool]$OriginalHadTerminalNewline = $true) {
    $entry = Get-KarambitModEntry $ModsPath
    if ($Action -eq 'add') {
        if ($entry.State -ne 'absent') { throw 'KarambitPort mod registration changed during installation.' }
        $newline = [Environment]::NewLine
        $text = $entry.Text
        if ($text.Length -gt 0 -and -not ($text.EndsWith([char]10) -or $text.EndsWith([char]13))) { $text += $newline }
        $text += 'KarambitPort : 1' + $newline
    } elseif ($Action -eq 'enable') {
        if ($entry.State -ne 'disabled') { throw 'KarambitPort mod registration changed during installation.' }
        $text = $entry.Text.Remove($entry.Match.Index, $entry.Match.Length).Insert($entry.Match.Index, 'KarambitPort : 1')
    } elseif ($Action -eq 'undo-add') {
        if ($entry.State -ne 'enabled' -or $entry.Match.Value.Trim() -ne 'KarambitPort : 1') {
            throw 'KarambitPort registration was changed by another program; refusing to remove it.'
        }
        $length = $entry.Match.Length
        if ($entry.Match.Index + $length -lt $entry.Text.Length -and $entry.Text[$entry.Match.Index + $length] -eq [char]10) { $length++ }
        $removedAtEnd = ($entry.Match.Index + $length -eq $entry.Text.Length)
        $text = $entry.Text.Remove($entry.Match.Index, $length)
        if ($removedAtEnd -and -not $OriginalHadTerminalNewline -and $text.Length -gt 0) {
            if ($text.EndsWith([string][char]10)) {
                $removeLength = if ($text.Length -gt 1 -and $text[$text.Length - 2] -eq [char]13) { 2 } else { 1 }
                $text = $text.Substring(0, $text.Length - $removeLength)
            } elseif ($text.EndsWith([string][char]13)) {
                $text = $text.Substring(0, $text.Length - 1)
            }
        }
    } elseif ($Action -eq 'undo-enable') {
        if ($entry.State -ne 'enabled' -or $entry.Match.Value.Trim() -ne 'KarambitPort : 1') {
            throw 'KarambitPort registration was changed by another program; refusing to restore its old state.'
        }
        $text = $entry.Text.Remove($entry.Match.Index, $entry.Match.Length).Insert($entry.Match.Index, $OriginalLine)
    } else {
        throw "Unknown mod entry action: $Action"
    }
    Write-KarambitAtomicText $ModsPath $text
}

function Write-KarambitAtomicText([string]$Target, [string]$Text) {
    $directory = Split-Path -Parent $Target
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $temp = Join-Path $directory ('.karambit-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    $existingBom = $false
    if ([IO.File]::Exists($Target)) {
        $bytes = [IO.File]::ReadAllBytes($Target)
        $existingBom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
    }
    try {
        [IO.File]::WriteAllText($temp, $Text, (New-Object Text.UTF8Encoding($existingBom)))
        if ([IO.File]::Exists($Target)) { [IO.File]::Replace($temp, $Target, ($temp + '.previous')) }
        else { [IO.File]::Move($temp, $Target) }
    } finally {
        if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) }
        if ([IO.File]::Exists($temp + '.previous')) { [IO.File]::Delete($temp + '.previous') }
    }
}

function Copy-KarambitAtomic([string]$Source, [string]$Target, [string]$ExpectedHash) {
    $directory = Split-Path -Parent $Target
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $temp = Join-Path $directory ('.karambit-' + [Guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::Copy($Source, $temp)
        Assert-KarambitHash $temp $ExpectedHash 'Staged file'
        if ([IO.File]::Exists($Target)) { [IO.File]::Replace($temp, $Target, ($temp + '.previous')) }
        else { [IO.File]::Move($temp, $Target) }
    } finally {
        if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) }
        if ([IO.File]::Exists($temp + '.previous')) { [IO.File]::Delete($temp + '.previous') }
    }
}

function New-KarambitPatchedExecutable([string]$Source, [string]$Target, [string]$PristineHash, [string]$PatchedHash) {
    Assert-KarambitHash $Source $PristineHash 'Pristine Season 2 executable'
    $data = [IO.File]::ReadAllBytes($Source)
    $patches = @(
        @{ Offset=0x352DF54; Before=[byte[]](0x80,0x3D,0xB5,0x1B,0x06,0x03,0x03); After=[byte[]](0xEB,0xF7,0x90,0x90,0x90,0x90,0x90) },
        @{ Offset=0x35394E8; Before=[byte[]](0x0F,0x84,0x83,0x07,0x00,0x00); After=[byte[]](0x90,0x90,0x90,0x90,0x90,0x90) }
    )
    $changed = 0
    foreach ($patch in $patches) {
        for ($i=0; $i -lt $patch.Before.Length; $i++) {
            $index = [int]$patch.Offset + $i
            if ($index -ge $data.Length -or $data[$index] -ne $patch.Before[$i]) {
                throw ("Unexpected executable bytes at file offset 0x{0:X}. Patch refused." -f $index)
            }
            if ($data[$index] -ne $patch.After[$i]) { $changed++ }
            $data[$index] = $patch.After[$i]
        }
    }
    if ($changed -ne 13) { throw "Expected exactly 13 changed bytes, found $changed." }
    [IO.File]::WriteAllBytes($Target, $data)
    Assert-KarambitHash $Target $PatchedHash 'Patched Season 2 executable'
}

function Assert-KarambitPayload([object]$Package, [string]$PackageRoot) {
    foreach ($file in $Package.Files) {
        $path = Join-Path $PackageRoot $file.Payload
        Assert-KarambitHash $path $file.Sha256 $file.Payload
    }
}

function Get-KarambitContext([string]$Root, [object]$Package) {
    $exe = Join-Path $Root 'Prospect\Binaries\Win64\Prospect-Win64-Shipping.exe'
    $loader = Join-Path $Root 'Prospect\Binaries\Win64\Prospect.Client.Loader.exe'
    $ue4ss = Join-Path $Root 'Prospect\Binaries\Win64\UE4SS.dll'
    $xinput = Join-Path $Root 'Prospect\Binaries\Win64\xinput1_3.dll'
    $mods = Join-Path $Root 'Prospect\Binaries\Win64\Mods\mods.txt'
    $exeHash = Get-KarambitHash $exe
    if ($exeHash -ne $Package.CompatibleExecutablePristineSha256 -and $exeHash -ne $Package.CompatibleExecutablePatchedSha256) {
        throw "Unsupported game executable SHA-256: $exeHash. This add-on supports only the exact Season 2 build listed in README."
    }
    if (-not [IO.File]::Exists($loader)) { Write-Warning "Tested client loader is absent. Your launcher must already provide a working login/API launch chain." }
    if (-not [IO.File]::Exists($ue4ss)) { throw "UE4SS.dll is missing: $ue4ss" }
    if (-not [IO.File]::Exists($xinput)) { throw "UE4SS xinput1_3.dll shim is missing: $xinput" }
    if (-not [IO.File]::Exists($mods)) { throw "UE4SS Mods\mods.txt is missing: $mods" }
    foreach ($dependency in @(
        @{Path=$ue4ss; Expected=$Package.CompatibleUE4SSSha256; Label='UE4SS'},
        @{Path=$xinput; Expected=$Package.CompatibleXinputShimSha256; Label='UE4SS xinput shim'}
    )) {
        $hash = Get-KarambitHash $dependency.Path
        if ($hash -ne $dependency.Expected) {
            Write-Warning "$($dependency.Label) differs from the tested copy ($hash). Installation can continue, but runtime compatibility is unverified."
        }
    }
    if ([IO.File]::Exists($loader) -and (Get-KarambitHash $loader) -ne $Package.CompatibleClientLoaderSha256) {
        Write-Warning 'Client loader differs from the tested copy; runtime compatibility is unverified.'
    }
    return [pscustomobject]@{
        Root=$Root; Exe=$exe; ExeHash=$exeHash; Mods=$mods;
        Manifest=(Join-Path $Root 'KarambitPort.Install.json')
    }
}

function Assert-KarambitManagedState([object]$Manifest, [object]$Package, [object]$Context) {
    if ($Manifest.PackageId -ne $Package.PackageId -or $Manifest.State -ne 'installed') {
        throw 'An incompatible or unfinished Karambit installation manifest exists. Do not overwrite it.'
    }
    foreach ($file in $Package.Files) {
        Assert-KarambitHash (Join-Path $Context.Root $file.Target) $file.Sha256 $file.Target
    }
    Assert-KarambitHash $Context.Exe $Package.CompatibleExecutablePatchedSha256 'Game executable'
    if ((Get-KarambitModEntry $Context.Mods).State -ne 'enabled') {
        throw 'KarambitPort is no longer enabled in UE4SS Mods\mods.txt.'
    }
}

function Undo-KarambitPartialInstall([object]$Manifest, [object]$Package, [object]$Context) {
    Assert-KarambitInstallRecord $Manifest $Package
    if ($Manifest.State -ne 'installing') {
        throw 'Refusing to recover a manifest that is not marked installing.'
    }
    $backupRoot = Join-Path $Context.Root $Manifest.BackupRoot
    foreach ($record in $Manifest.Files) {
        if (-not $record.Owned) { continue }
        $target = Join-Path $Context.Root $record.Target
        $current = Get-KarambitHash $target
        if ($record.OriginalExisted) {
            $backup = Join-Path $backupRoot $record.BackupName
            Assert-KarambitHash $backup $record.OriginalSha256 'Recovery backup'
            if ($current -ne $record.OriginalSha256 -and $current -ne $record.PayloadSha256) {
                throw "Cannot recover changed file: $target"
            }
            if ($current -ne $record.OriginalSha256) {
                Copy-KarambitAtomic $backup $target $record.OriginalSha256
            }
        } else {
            if ($null -ne $current -and $current -ne $record.PayloadSha256) {
                throw "Cannot recover changed file: $target"
            }
            if ($null -ne $current) { [IO.File]::Delete($target) }
        }
    }
    if ($Manifest.ExePatchedByUs) {
        $backup = Join-Path $backupRoot 'GameExecutable.before'
        Assert-KarambitHash $backup $Package.CompatibleExecutablePristineSha256 'Game executable backup'
        $current = Get-KarambitHash $Context.Exe
        if ($current -ne $Package.CompatibleExecutablePristineSha256 -and $current -ne $Package.CompatibleExecutablePatchedSha256) {
            throw 'Cannot recover game executable: its contents changed.'
        }
        if ($current -eq $Package.CompatibleExecutablePatchedSha256) {
            Copy-KarambitAtomic $backup $Context.Exe $Package.CompatibleExecutablePristineSha256
        }
    }
    if ($Manifest.ModEntryAction -eq 'add') {
        $entry = Get-KarambitModEntry $Context.Mods
        $hadTerminalNewline = $true
        if ($null -ne $Manifest.PSObject.Properties['ModOriginalHadTerminalNewline']) {
            $hadTerminalNewline = [bool]$Manifest.ModOriginalHadTerminalNewline
        }
        if ($entry.State -eq 'enabled') { Set-KarambitModEntry $Context.Mods 'undo-add' $null $hadTerminalNewline }
        elseif ($entry.State -ne 'absent') { throw 'Cannot recover changed KarambitPort mod registration.' }
    } elseif ($Manifest.ModEntryAction -eq 'enable') {
        $entry = Get-KarambitModEntry $Context.Mods
        if ($entry.State -eq 'enabled') { Set-KarambitModEntry $Context.Mods 'undo-enable' $Manifest.ModOriginalLine }
        elseif ($entry.State -ne 'disabled') { throw 'Cannot recover changed KarambitPort mod registration.' }
    }
    [IO.File]::Delete($Context.Manifest)
}

function Assert-KarambitPackageSchema([object]$Package) {
    if ($Package.PackageId -ne 'KarambitPort-S2-20261001' -or $Package.Version -ne 2) {
        throw 'Package identity is not the expected KarambitPort Season 2 release.'
    }
    $expectedFiles = @(
        @('Payload\pakchunk99-WindowsNoEditor_P.pak','Prospect\Content\Paks\pakchunk99-WindowsNoEditor_P.pak','B37F202CD8BEE7EF8846A247308B5E17E391238A8B224D632A09379BCBF3355D'),
        @('Payload\pakchunk99-WindowsNoEditor_P.sig','Prospect\Content\Paks\pakchunk99-WindowsNoEditor_P.sig','1738091FCA92CDE809F21CEA98884C93C2B450BD0F78B8DE968DBFE67C01BA18'),
        @('Payload\KarambitPort\Scripts\main.lua','Prospect\Binaries\Win64\Mods\KarambitPort\Scripts\main.lua','9CB53ACCCF43EFD762D6DF53E1C2142DB88650E8C1084B51FAA3096E70A79C6E'),
        @('Payload\KarambitPort\enabled.txt','Prospect\Binaries\Win64\Mods\KarambitPort\enabled.txt','E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855')
    )
    if ($Package.Files.Count -ne $expectedFiles.Count) { throw 'Package file list length is invalid.' }
    for ($i=0; $i -lt $expectedFiles.Count; $i++) {
        if ($Package.Files[$i].Payload -ne $expectedFiles[$i][0] -or
            $Package.Files[$i].Target -ne $expectedFiles[$i][1] -or
            $Package.Files[$i].Sha256 -ne $expectedFiles[$i][2]) {
            throw "Package file entry $i differs from the fixed, tested release."
        }
    }
    if ($Package.CompatibleExecutablePristineSha256 -ne '8BA99826C15028C40A633AA3491F6FB0C323897405538859F36548346095055C' -or
        $Package.CompatibleExecutablePatchedSha256 -ne 'A5098B8A1A8178BB84A8E131F8F71D39C3D32B496F4407392533DF82386CA08A') {
        throw 'Package executable compatibility hashes differ from the fixed, tested release.'
    }
}

function Assert-KarambitInstallRecord([object]$Manifest, [object]$Package) {
    if ($Manifest.PackageId -ne $Package.PackageId -or
        $Manifest.State -notin @('installing','installed','uninstalling')) {
        throw 'Installation record identity or state is invalid.'
    }
    if ($Manifest.BackupRoot -notmatch '^KarambitPort\.Backups\\[0-9a-fA-F]{32}$') {
        throw 'Installation record backup path is invalid.'
    }
    if ($Manifest.Files.Count -ne $Package.Files.Count) { throw 'Installation record file list length is invalid.' }
    for ($i=0; $i -lt $Package.Files.Count; $i++) {
        $record = $Manifest.Files[$i]
        $expected = $Package.Files[$i]
        if ($record.Target -ne $expected.Target -or $record.PayloadSha256 -ne $expected.Sha256) {
            throw "Installation record target $i differs from the fixed release."
        }
        if ($record.Owned -and $record.OriginalExisted) {
            if ($record.BackupName -ne ('File{0:D2}.before' -f $i)) {
                throw "Installation record backup filename $i is invalid."
            }
            if ($record.OriginalSha256 -notmatch '^[0-9a-fA-F]{64}$') {
                throw "Installation record original hash $i is invalid."
            }
        } elseif (-not [string]::IsNullOrEmpty($record.BackupName)) {
            throw "Installation record backup filename $i should be empty."
        }
    }
    if ($Manifest.ModEntryAction -notin @('add','enable','none')) {
        throw 'Installation record mod action is invalid.'
    }
    if ($Manifest.ModEntryAction -eq 'enable' -and
        $Manifest.ModOriginalLine -notmatch '^[ \t]*KarambitPort[ \t]*:[ \t]*0[ \t]*\r?$') {
        throw 'Installation record original UE4SS line is invalid.'
    }
}
