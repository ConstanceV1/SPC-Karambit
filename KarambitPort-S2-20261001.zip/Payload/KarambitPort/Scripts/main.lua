-- Singleplayer Karambit runtime asset and table diagnostic.
local function describe(name, path)
    local ok, object = pcall(LoadAsset, path)
    local valid_ok, is_valid = pcall(function() return object ~= nil and object:IsValid() end)
    local full_ok, full = pcall(function() return object ~= nil and object:GetFullName() end)
    print(string.format('[KarambitPort] %s loaded=%s valid=%s name=%s detail=%s\n',
        name, tostring(ok), tostring(valid_ok and is_valid),
        full_ok and tostring(full) or '<unavailable>', tostring(object)))
    if ok and valid_ok and is_valid then return object end
end
local function scan()
    local registry = FindFirstOf('AssetRegistryImpl')
    if registry == nil then
        print('[KarambitPort] registry=missing\n')
        return
    end
    local ok_before, before = pcall(function()
        return registry:HasAssets(FName('/Game/Weapons/Melee/Karambit01', EFindName.FNAME_Add), true)
    end)
    print('[KarambitPort] registry-has-before=' .. tostring(ok_before and before) .. '\n')
    local paths = {
        '/Game/Weapons/Melee/Karambit01',
        '/Game/UI/Textures/Vanity/Melee',
        '/Game/Animation/Player/1P/Melee/Karambit',
        '/Game/Animation/Player/3P/Melee/Karambit',
        '/Game/Audio/SFX/Weapons/WP_Melee/WP_Melee_Karambit',
    }
    local ok, err = pcall(function() registry:ScanPathsSynchronous(paths, true) end)
    print('[KarambitPort] registry-scan=' .. tostring(ok) .. ' detail=' .. tostring(err) .. '\n')
    local ok_after, after = pcall(function()
        return registry:HasAssets(FName('/Game/Weapons/Melee/Karambit01', EFindName.FNAME_Add), true)
    end)
    print('[KarambitPort] registry-has-after=' .. tostring(ok_after and after) .. '\n')
end
local function check()
    scan()
    local cosmetic = describe('cosmetic','/Game/DataTables/Backend/MeleeWeapons_DT.MeleeWeapons_DT')
    local weapon = describe('weapon','/Game/DataTables/PRO_MeleeWeapons.PRO_MeleeWeapons')
    describe('S2-control-mesh','/Game/Weapons/Melee/UNI_CultistKnife/WP_Melee_COT_CultistKnife_SK.WP_Melee_COT_CultistKnife_SK')
    describe('mesh','/Game/Weapons/Melee/Karambit01/WP_Melee_Karambit01_SK.WP_Melee_Karambit01_SK')
    describe('mesh-short','/Game/Weapons/Melee/Karambit01/WP_Melee_Karambit01_SK')
    describe('icon','/Game/UI/Textures/Vanity/Melee/UI_Vanity_Melee_Karambit01.UI_Vanity_Melee_Karambit01')
    describe('attack','/Game/Animation/Player/1P/Melee/Karambit/1P_Karambit_Attack_Light_01_Montage.1P_Karambit_Attack_Light_01_Montage')
    local lib = StaticFindObject('/Script/Engine.Default__DataTableFunctionLibrary')
    for _, row in ipairs({{'cosmetic',cosmetic,'Melee_Karambit01'},{'weapon',weapon,'Melee_Karambit_01'}}) do
        local ok, found = pcall(function()
            return lib:DoesDataTableRowExist(row[2],FName(row[3],EFindName.FNAME_Find))
        end)
        print('[KarambitPort] ' .. row[1] .. '-row=' .. tostring(ok and found) .. '\n')
    end
end
ExecuteWithDelay(6000,function()
    ExecuteInGameThread(function()
        local ok, err = pcall(check)
        if not ok then print('[KarambitPort] probe-error=' .. tostring(err) .. '\n') end
    end)
end)
print('[KarambitPort] loaded\n')





-- Cache Karambit audio away from the swing input callback.
local cue_path = '/Game/Audio/SFX/Weapons/WP_Melee/WP_Melee_Karambit/WP_Melee_BladeKarambit_FastAttack.WP_Melee_BladeKarambit_FastAttack'
local cached_cue, cached_audio_lib
local audio_warm_logged, first_audio_logged = false, false

local function valid(object)
    if object == nil then return false end
    local ok, result = pcall(function() return object:IsValid() end)
    return ok and result
end

local function full_name(object)
    if not valid(object) then return '<none>' end
    local ok, result = pcall(function() return object:GetFullName() end)
    return ok and tostring(result) or '<unavailable>'
end


local function warm_resources()
    if not valid(cached_cue) then
        local ok, result = pcall(LoadAsset, cue_path)
        if ok and valid(result) then cached_cue = result end
    end
    if not valid(cached_audio_lib) then
        local ok, result = pcall(StaticFindObject, '/Script/Engine.Default__GameplayStatics')
        if ok and valid(result) then cached_audio_lib = result end
    end
    if not audio_warm_logged then
        print('[KarambitPort] audio preloaded cue=' .. tostring(valid(cached_cue))
            .. ' lib=' .. tostring(valid(cached_audio_lib)) .. '\n')
        audio_warm_logged = true
    end
    ExecuteWithDelay(5000, function() ExecuteInGameThread(function()
        local ok, err = pcall(warm_resources)
        if not ok then print('[KarambitPort] audio warm-error=' .. tostring(err) .. '\n') end
    end) end)
end

ExecuteWithDelay(8000, function() ExecuteInGameThread(function()
    local ok, err = pcall(warm_resources)
    if not ok then print('[KarambitPort] audio warm-error=' .. tostring(err) .. '\n') end
end) end)

local function karambit_swing_audio(context)
    local ok, err = pcall(function()
        if not valid(cached_cue) or not valid(cached_audio_lib) then return end
        local weapon = context:get()
        if not valid(weapon) then return end
        local owner = weapon:GetOwner()
        if not valid(owner) or not owner:IsLocallyControlled() then return end
        local row = tostring(weapon.m_activeInstanceData.m_rowHandle.RowName:ToString())
        if row ~= 'Melee_Knife_01' then return end
        cached_audio_lib:PlaySound2D(owner, cached_cue, 0.85, 1.0, 0.0, nil, owner, false)
        if not first_audio_logged then
            print('[KarambitPort] audio first FastAttack played from cache\n')
            first_audio_logged = true
        end
    end)
    if not ok then print('[KarambitPort] audio-error=' .. tostring(err) .. '\n') end
end

local hook_ok, hook_err = pcall(function()
    RegisterHook('/Script/Prospect.YPlayerCharacterWeaponComponent:OnStartMelee', function() end, karambit_swing_audio)
end)
print('[KarambitPort] audio hook=' .. tostring(hook_ok) .. ' detail=' .. tostring(hook_err) .. '\n')

-- One settled switch event changes only the local first-person idle node.
local original_idle_path = '/Game/Animation/Player/1P/Melee/Idle/1P_Melee_Idle_01.1P_Melee_Idle_01'
local karambit_idle_path = '/Game/Animation/Player/1P/Melee/Karambit/1P_Karambit_Idle_01.1P_Karambit_Idle_01'
local original_idle, karambit_idle, cached_local_owner
local switch_generation = 0

local function refresh_grip_assets(reason)
    local ok, err = pcall(function()
        if not valid(original_idle) then
            original_idle = LoadAsset(original_idle_path)
        end
        if not valid(karambit_idle) then
            karambit_idle = LoadAsset(karambit_idle_path)
        end
        print('[KarambitPort] grip assets reason=' .. tostring(reason)
            .. ' original=' .. tostring(valid(original_idle))
            .. ' karambit=' .. tostring(valid(karambit_idle)) .. '\n')
    end)
    if not ok then print('[KarambitPort] grip refresh-error=' .. tostring(err) .. '\n') end
end

ExecuteWithDelay(10000, function()
    ExecuteInGameThread(function() refresh_grip_assets('startup') end)
end)


local function find_local_owner()
    if valid(cached_local_owner) then
        local ok, controlled = pcall(function() return cached_local_owner:IsLocallyControlled() end)
        if ok and controlled then return cached_local_owner end
    end
    cached_local_owner = nil
    for _, component in ipairs(FindAllOf('YPlayerCharacterWeaponComponent') or {}) do
        if valid(component) then
            local ok, actor = pcall(function() return component:GetOwner() end)
            if ok and valid(actor) then
                local control_ok, controlled = pcall(function() return actor:IsLocallyControlled() end)
                if control_ok and controlled and full_name(actor):find('/Game/Maps/MP/', 1, true) then
                    cached_local_owner = actor
                    return actor
                end
            end
        end
    end
end

local function apply_grip_after_switch(generation)
    print('[KarambitPort] grip delayed generation=' .. tostring(generation) .. ' latest=' .. tostring(switch_generation) .. ' original=' .. tostring(valid(original_idle)) .. ' karambit=' .. tostring(valid(karambit_idle)) .. '\n')
    if generation ~= switch_generation then return end
    if not valid(original_idle) or not valid(karambit_idle) then
        refresh_grip_assets('switch')
    end
    if not valid(original_idle) or not valid(karambit_idle) then return end
    local ok, err = pcall(function()
        local owner = find_local_owner()
        if not valid(owner) then
            print('[KarambitPort] grip event skipped: local owner missing\n')
            return
        end
        local weapon = owner.m_characterWeaponComponent
        local mesh = owner.m_firstPersonMesh
        if not valid(weapon) or not valid(mesh) then
            print('[KarambitPort] grip event skipped: weapon or mesh missing\n')
            return
        end
        local row = tostring(weapon.m_activeInstanceData.m_rowHandle.RowName:ToString())
        local desired = row == 'Melee_Knife_01'
        local target = desired and karambit_idle or original_idle
        local anim = mesh:GetAnimInstance()
        if not valid(anim) or not full_name(anim):find('CH_Player_ABP_C', 1, true) then
            print('[KarambitPort] grip event skipped: first-person anim missing\n')
            return
        end
        local node = anim.AnimGraphNode_SequencePlayer_227
        if not node then
            print('[KarambitPort] grip event skipped: idle node missing\n')
            return
        end
        local current = node.Sequence
        local current_name = full_name(current)
        local original_name = full_name(original_idle)
        local karambit_name = full_name(karambit_idle)
        if current_name ~= original_name and current_name ~= karambit_name then
            print('[KarambitPort] grip event skipped: unexpected sequence=' .. current_name .. '\n')
            return
        end
        if current_name ~= full_name(target) then
            node.Sequence = target
            local after = full_name(anim.AnimGraphNode_SequencePlayer_227.Sequence)
            print('[KarambitPort] grip event row=' .. row
                .. ' target=' .. (desired and 'karambit' or 'original')
                .. ' applied=' .. tostring(after == full_name(target)) .. '\n')
        else
            print('[KarambitPort] grip event row=' .. row
                .. ' target=' .. (desired and 'karambit' or 'original')
                .. ' already-set\n')
        end
    end)
    if not ok then print('[KarambitPort] grip event-error=' .. tostring(err) .. '\n') end
end

local event_ok, event_err = pcall(function()
    RegisterHook('/Script/Prospect.YPlayerCharacterWeaponComponent:OnStartWeaponSwitch',
        function() end,
        function(context)
            local context_ok, context_err = pcall(function()
                local component = context:get()
                local owner = component:GetOwner()
                if valid(owner) and owner:IsLocallyControlled() then
                    cached_local_owner = owner
                end
            end)
            if not context_ok then
                print('[KarambitPort] switch owner-error=' .. tostring(context_err) .. '\n')
            end
            print('[KarambitPort] grip switch callback received\n')
            switch_generation = switch_generation + 1
            local generation = switch_generation
            ExecuteWithDelay(1000, function() ExecuteInGameThread(function()
                apply_grip_after_switch(generation)
            end) end)
        end)
end)
print('[KarambitPort] grip event hook=' .. tostring(event_ok)
    .. ' detail=' .. tostring(event_err) .. '\n')
-- The pawn can spawn with the Karambit already active, so no weapon-switch event fires.
-- Recheck only after pawn assignment; newer pawn/switch events cancel older checks.
local pawn_grip_ok, pawn_grip_err = pcall(function()
    RegisterHook('/Script/Prospect.YWeaponPlayerControllerRuntimeComponent:OnPawnAssigned',
        function() end,
        function()
            cached_local_owner = nil
            switch_generation = switch_generation + 1
            local generation = switch_generation
            print('[KarambitPort] grip pawn event generation=' .. generation .. '\n')
            for _, delay in ipairs({6000, 12000}) do
                ExecuteWithDelay(delay, function()
                    ExecuteInGameThread(function()
                        if generation == switch_generation then
                            apply_grip_after_switch(generation)
                        end
                    end)
                end)
            end
        end)
end)
print('[KarambitPort] grip pawn hook=' .. tostring(pawn_grip_ok)
    .. ' detail=' .. tostring(pawn_grip_err) .. '\n')