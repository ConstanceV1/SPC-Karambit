@echo off
setlocal
if "%~1"=="" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Karambit.ps1"
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Karambit.ps1" -GameRoot "%~1"
)
set "RESULT=%ERRORLEVEL%"
echo.
if "%RESULT%"=="0" (echo Karambit is ready.) else (echo Installer stopped. Read the message above.)
pause
exit /b %RESULT%
