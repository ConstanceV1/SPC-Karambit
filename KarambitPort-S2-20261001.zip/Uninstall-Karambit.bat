@echo off
setlocal
if "%~1"=="" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-Karambit.ps1"
) else (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-Karambit.ps1" -GameRoot "%~1"
)
set "RESULT=%ERRORLEVEL%"
echo.
if "%RESULT%"=="0" (echo Uninstall finished.) else (echo Uninstaller stopped. Read the message above.)
pause
exit /b %RESULT%
