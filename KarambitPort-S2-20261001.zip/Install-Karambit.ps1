﻿[CmdletBinding()]
param(
    [string]$GameRoot,
    [switch]$CheckOnly,
    [switch]$ReplaceExisting
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Karambit.Common.ps1')

$planWritten = $false
$installPlan = $null
$context = $null
$package = $null
try {
    $packagePath = Join-Path $PSScriptRoot 'PackageManifest.json'
    $package = Get-Content -LiteralPath $packagePath -Raw | ConvertFrom-Json
    Assert-KarambitPackageSchema $package
    Assert-KarambitPayload $package $PSScriptRoot
    $root = Resolve-KarambitGameRoot $GameRoot
    $context = Get-KarambitContext $root $package

    if ([IO.File]::Exists($context.Manifest)) {
        $previous = Get-Content -LiteralPath $context.Manifest -Raw | ConvertFrom-Json
        Assert-KarambitInstallRecord $previous $package
        if ($previous.State -eq 'installing' -and -not $CheckOnly) {
            Test-KarambitGameStopped $context.Exe
            Write-Warning 'Recovering a previously interrupted Karambit installation.'
            Undo-KarambitPartialInstall $previous $package $context
            $context = Get-KarambitContext $root $package
        } else {
            Assert-KarambitManagedState $previous $package $context
            Write-Host 'Karambit is already installed and managed. All hashes and UE4SS registration match.'
            exit 0
        }
    }

    $allPayloadPresent = $true
    $different = New-Object System.Collections.Generic.List[string]
    foreach ($file in $package.Files) {
        $target = Join-Path $root $file.Target
        $hash = Get-KarambitHash $target
        if ($hash -ne $file.Sha256) {
            $allPayloadPresent = $false
            if ($null -ne $hash) { $different.Add($file.Target) }
        }
    }
    $modEntry = Get-KarambitModEntry $context.Mods
    $ready = $allPayloadPresent -and
        $context.ExeHash -eq $package.CompatibleExecutablePatchedSha256 -and
        $modEntry.State -eq 'enabled'
    if ($ready) {
        Write-Host 'Karambit files are already present and working, but this installer does not own them.'
        Write-Host 'No manifest or backup was created. Uninstall-Karambit.ps1 will not remove them.'
        exit 0
    }
    if ($CheckOnly) {
        Write-Host "Karambit installation needed. Executable: $($context.ExeHash); payload present: $allPayloadPresent; mod entry: $($modEntry.State)."
        exit 2
    }
    Test-KarambitGameStopped $context.Exe
    if ($different.Count -gt 0 -and -not $ReplaceExisting) {
        throw "Existing Karambit target files differ from this release: $($different -join ', '). No files changed. To back them up and replace them, explicitly rerun with -ReplaceExisting."
    }

    $runId = [Guid]::NewGuid().ToString('N')
    $backupRel = Join-Path 'KarambitPort.Backups' $runId
    $backupRoot = Join-Path $root $backupRel
    [IO.Directory]::CreateDirectory($backupRoot) | Out-Null
    $records = @()
    $index = 0
    foreach ($file in $package.Files) {
        $target = Join-Path $root $file.Target
        $originalHash = Get-KarambitHash $target
        $owned = $originalHash -ne $file.Sha256
        $originalExists = $null -ne $originalHash
        $backupName = $null
        if ($owned -and $originalExists) {
            $backupName = ('File{0:D2}.before' -f $index)
            $backup = Join-Path $backupRoot $backupName
            [IO.File]::Copy($target, $backup)
            Assert-KarambitHash $backup $originalHash 'Original target backup'
        }
        $records += [pscustomobject]@{
            Target=$file.Target; PayloadSha256=$file.Sha256; Owned=$owned;
            OriginalExisted=$originalExists; OriginalSha256=$originalHash;
            BackupName=$backupName
        }
        $index++
    }

    $patchExe = $context.ExeHash -eq $package.CompatibleExecutablePristineSha256
    if ($patchExe) {
        $exeBackup = Join-Path $backupRoot 'GameExecutable.before'
        [IO.File]::Copy($context.Exe, $exeBackup)
        Assert-KarambitHash $exeBackup $package.CompatibleExecutablePristineSha256 'Original executable backup'
        $patchedStage = Join-Path $backupRoot 'GameExecutable.patched-stage'
        New-KarambitPatchedExecutable $exeBackup $patchedStage $package.CompatibleExecutablePristineSha256 $package.CompatibleExecutablePatchedSha256
    }
    $modAction = switch ($modEntry.State) {
        'absent' { 'add' }
        'disabled' { 'enable' }
        'enabled' { 'none' }
        default { throw 'Unexpected UE4SS mod registration state.' }
    }
    $oldLine = if ($modEntry.State -eq 'disabled') { $modEntry.Match.Value } else { $null }
    if ($modAction -ne 'none') {
        $modsBackup = Join-Path $backupRoot 'Mods.txt.before'
        [IO.File]::Copy($context.Mods, $modsBackup)
        Assert-KarambitHash $modsBackup (Get-KarambitHash $context.Mods) 'Original UE4SS mods.txt backup'
    }

    $installPlan = [pscustomobject]@{
        PackageId=$package.PackageId; State='installing'; InstalledAtUtc=[DateTime]::UtcNow.ToString('o');
        BackupRoot=$backupRel; Files=$records;
        ExePatchedByUs=$patchExe; ModEntryAction=$modAction; ModOriginalLine=$oldLine;
        ModOriginalHadTerminalNewline=($modEntry.Text.Length -eq 0 -or $modEntry.Text.EndsWith([string][char]10) -or $modEntry.Text.EndsWith([string][char]13))
    }
    Write-KarambitAtomicText $context.Manifest ($installPlan | ConvertTo-Json -Depth 10)
    $planWritten = $true

    if ($patchExe) {
        Copy-KarambitAtomic $patchedStage $context.Exe $package.CompatibleExecutablePatchedSha256
    }
    foreach ($file in $package.Files) {
        $target = Join-Path $root $file.Target
        if ((Get-KarambitHash $target) -ne $file.Sha256) {
            Copy-KarambitAtomic (Join-Path $PSScriptRoot $file.Payload) $target $file.Sha256
        }
    }
    if ($modAction -ne 'none') { Set-KarambitModEntry $context.Mods $modAction $oldLine }

    foreach ($file in $package.Files) {
        Assert-KarambitHash (Join-Path $root $file.Target) $file.Sha256 $file.Target
    }
    Assert-KarambitHash $context.Exe $package.CompatibleExecutablePatchedSha256 'Installed executable'
    if ((Get-KarambitModEntry $context.Mods).State -ne 'enabled') {
        throw 'KarambitPort mod was not enabled after installation.'
    }
    $installPlan.State = 'installed'
    Write-KarambitAtomicText $context.Manifest ($installPlan | ConvertTo-Json -Depth 10)
    if ($patchExe -and [IO.File]::Exists($patchedStage)) {
        try { [IO.File]::Delete($patchedStage) } catch { Write-Warning 'Installed successfully, but the temporary patched executable in the backup folder could not be deleted.' }
    }
    Write-Host "Karambit installed in $root"
    Write-Host "Backups and manifest remain in $backupRel. Launch through your existing working launcher."
    exit 0
} catch {
    $failure = $_.Exception.Message
    if ($planWritten -and $null -ne $installPlan -and $null -ne $context) {
        try {
            Undo-KarambitPartialInstall $installPlan $package $context
            Write-Host 'Installation failed; original files were restored.'
        } catch {
            Write-Host "Automatic rollback could not finish: $($_.Exception.Message)" -ForegroundColor Red
            Write-Host "Keep the backup folder and inspect $($context.Manifest) before retrying." -ForegroundColor Red
        }
    }
    Write-Host "Karambit installer failed: $failure" -ForegroundColor Red
    exit 1
}
