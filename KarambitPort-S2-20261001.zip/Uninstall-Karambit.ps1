﻿[CmdletBinding()]
param([string]$GameRoot)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Karambit.Common.ps1')

try {
    $package = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PackageManifest.json') -Raw | ConvertFrom-Json
    Assert-KarambitPackageSchema $package
    $root = Resolve-KarambitGameRoot $GameRoot
    $exe = Join-Path $root 'Prospect\Binaries\Win64\Prospect-Win64-Shipping.exe'
    $context = [pscustomobject]@{
        Root=$root; Exe=$exe; ExeHash=(Get-KarambitHash $exe);
        Mods=(Join-Path $root 'Prospect\Binaries\Win64\Mods\mods.txt');
        Manifest=(Join-Path $root 'KarambitPort.Install.json')
    }
    if (-not [IO.File]::Exists($context.Manifest)) {
        Write-Host 'No managed Karambit installation exists here. Nothing was removed.'
        exit 0
    }
    $record = Get-Content -LiteralPath $context.Manifest -Raw | ConvertFrom-Json
    if ($record.PackageId -ne $package.PackageId -or $record.State -notin @('installed','uninstalling')) {
        throw 'This Karambit manifest is incompatible or still installing. No files were removed.'
    }
    Assert-KarambitInstallRecord $record $package
    $backupRoot = Join-Path $root $record.BackupRoot
    Test-KarambitGameStopped $context.Exe

    for ($i=0; $i -lt $package.Files.Count; $i++) {
        $expected = $package.Files[$i]
        $file = $record.Files[$i]
        if ($file.Target -ne $expected.Target -or $file.PayloadSha256 -ne $expected.Sha256) {
            throw 'Installation manifest target list differs from this package.'
        }
        if (-not $file.Owned) { continue }
        $target = Join-Path $root $file.Target
        $current = Get-KarambitHash $target
        if ($file.OriginalExisted) {
            if ($file.BackupName -notmatch '^File[0-9]{2}\.before$') { throw 'Invalid backup filename in manifest.' }
            $backup = Join-Path $backupRoot $file.BackupName
            Assert-KarambitHash $backup $file.OriginalSha256 'Original file backup'
            if ($current -ne $file.PayloadSha256 -and $current -ne $file.OriginalSha256) {
                throw "File changed since Karambit installation; preserving it: $target"
            }
        } else {
            if ($null -ne $current -and $current -ne $file.PayloadSha256) {
                throw "File changed since Karambit installation; preserving it: $target"
            }
        }
    }
    $restoreExe = $false
    if ($record.ExePatchedByUs) {
        Assert-KarambitHash (Join-Path $backupRoot 'GameExecutable.before') $package.CompatibleExecutablePristineSha256 'Original game executable backup'
        $restoreExe = $context.ExeHash -eq $package.CompatibleExecutablePatchedSha256
        if (-not $restoreExe -and $context.ExeHash -ne $package.CompatibleExecutablePristineSha256) {
            Write-Warning 'Game executable changed after installation. Preserving its current bytes; only Karambit-owned add-on files will be removed.'
        }
    }
    $modsAvailable = [IO.File]::Exists($context.Mods)
    if ($modsAvailable) {
        $modEntry = Get-KarambitModEntry $context.Mods
        if ($record.ModEntryAction -eq 'add' -and $modEntry.State -notin @('enabled','absent')) {
            throw 'KarambitPort mod entry changed after installation; preserving mods.txt.'
        }
        if ($record.ModEntryAction -eq 'enable' -and $modEntry.State -notin @('enabled','disabled')) {
            throw 'KarambitPort mod entry changed after installation; preserving mods.txt.'
        }
    } elseif ($record.ModEntryAction -ne 'none') {
        Write-Warning 'UE4SS mods.txt is missing. Its Karambit registration is already absent and will not be recreated.'
    }

    if ($record.State -eq 'installed') {
        $record.State = 'uninstalling'
        Write-KarambitAtomicText $context.Manifest ($record | ConvertTo-Json -Depth 10)
    }
    foreach ($file in $record.Files) {
        if (-not $file.Owned) { continue }
        $target = Join-Path $root $file.Target
        if ($file.OriginalExisted) {
            if ((Get-KarambitHash $target) -ne $file.OriginalSha256) {
                Copy-KarambitAtomic (Join-Path $backupRoot $file.BackupName) $target $file.OriginalSha256
            }
        } elseif ([IO.File]::Exists($target)) {
            [IO.File]::Delete($target)
        }
    }
    if ($restoreExe) {
        Copy-KarambitAtomic (Join-Path $backupRoot 'GameExecutable.before') $context.Exe $package.CompatibleExecutablePristineSha256
    }
    if ($modsAvailable) {
        $modEntry = Get-KarambitModEntry $context.Mods
        if ($record.ModEntryAction -eq 'add' -and $modEntry.State -eq 'enabled') {
            $hadTerminalNewline = $true
            if ($null -ne $record.PSObject.Properties['ModOriginalHadTerminalNewline']) {
                $hadTerminalNewline = [bool]$record.ModOriginalHadTerminalNewline
            }
            Set-KarambitModEntry $context.Mods 'undo-add' $null $hadTerminalNewline
        } elseif ($record.ModEntryAction -eq 'enable' -and $modEntry.State -eq 'enabled') {
            Set-KarambitModEntry $context.Mods 'undo-enable' $record.ModOriginalLine
        }
    }
    foreach ($file in $record.Files) {
        if (-not $file.Owned) { continue }
        $target = Join-Path $root $file.Target
        if ($file.OriginalExisted) {
            Assert-KarambitHash $target $file.OriginalSha256 'Restored target'
        } elseif ([IO.File]::Exists($target)) {
            throw "Could not remove installed Karambit file: $target"
        }
    }
    if ($record.ExePatchedByUs -and $context.ExeHash -in @(
        $package.CompatibleExecutablePatchedSha256,
        $package.CompatibleExecutablePristineSha256
    )) {
        Assert-KarambitHash $context.Exe $package.CompatibleExecutablePristineSha256 'Restored game executable'
    }
    [IO.File]::Delete($context.Manifest)
    Write-Host "Karambit uninstalled from $root"
    Write-Host "Backup archive retained at $backupRoot. Other mods and launcher files were left alone."
    exit 0
} catch {
    Write-Host "Karambit uninstaller stopped: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'If an uninstall was interrupted, close the game and rerun this script; it resumes from the manifest.' -ForegroundColor Yellow
    exit 1
}
