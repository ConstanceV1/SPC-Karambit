﻿# Karambit for the Season 2 Prospect local project

This is a portable add-on for the **exact Season 2 Prospect build** tested here. It installs the working Karambit asset pak and UE4SS Lua mod. It also applies the small, reversible executable patch needed for this local build to mount the pak. It does **not** include the game, an API, a launcher, Steam files, or UE4SS.

## 2026-10-01 candidate status

This v2 package contains a revised grip Lua script. Its installer has passed isolated file/rollback tests; the revised grip has **not yet been visually confirmed in game**. Keep the prior 2026-09-30 ZIP until that check is complete.

If the prior managed package is already installed, uninstall it with its own 2026-09-30 ZIP before installing this v2 package. The new installer deliberately refuses to take ownership of an older manifest.

## Install in a minute

1. Use a legitimate copy of the same Season 2 game build. Make sure your existing local-project launcher, API/login, and UE4SS already work.
2. Extract the ZIP anywhere. Keep the Payload folder, both .ps1 files, Karambit.Common.ps1, and PackageManifest.json together.
3. Close the game.
4. Double-click **Install-Karambit.bat**. If the game folder is not found nearby, enter the **folder that contains Prospect** (for example, D:\Games\TCF).
5. Launch the game through your existing working launcher. **Do not launch Prospect-Win64-Shipping.exe directly.** The tested local project uses a client loader and local API; direct launch can show error code 5.
6. Equip the Karambit in your existing save/cosmetics. Check the grip, light swing, finger-loop sound, charged swing, and frame pacing.

The installer checks each included payload file's SHA-256 before writing. It refuses unknown game executable hashes. It refuses to overwrite a different pakchunk99 or KarambitPort mod by default. If you intentionally want to replace one, use PowerShell with **-ReplaceExisting**; it backs up the prior files for uninstall.

## Existing launcher integration

The friend's launcher source is not part of this ZIP, so this package does not alter that launcher. The launcher can run the installer **once during its setup step**:

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<extracted add-on>\Install-Karambit.ps1" -GameRoot "<folder containing Prospect>"

Then launch the game using the launcher's normal API/login flow. Re-running the installer is safe and idempotent when the files already match. An optional read-only startup check is:

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<extracted add-on>\Install-Karambit.ps1" -GameRoot "<folder containing Prospect>" -CheckOnly

Exit codes: **0** = ready, **2** = compatible but installation needed, **1** = incompatible, unsafe collision, or other error. The launcher should stop if setup exits nonzero. It should not start the game directly.

## What changes

- Prospect\Content\Paks\pakchunk99-WindowsNoEditor_P.pak and .sig
- Prospect\Binaries\Win64\Mods\KarambitPort\Scripts\main.lua and empty enabled.txt
- One KarambitPort : 1 entry in Prospect\Binaries\Win64\Mods\mods.txt, preserving other entries
- **Only if pristine:** 13 bytes in Prospect-Win64-Shipping.exe, after exact whole-file and original-byte checks

The installation manifest is KarambitPort.Install.json in the game root. Replaced originals, including the pristine executable if patched, are backed up under KarambitPort.Backups\<installation ID> in that root. A successful uninstall leaves the backup archive available for manual recovery. The installer does not modify other mods, the launcher, API, TLS keys, account data, or saves.

### Exact executable compatibility

| State | SHA-256 |
| --- | --- |
| Pristine tested Season 2 executable | 8BA99826C15028C40A633AA3491F6FB0C323897405538859F36548346095055C |
| Tested 13-byte local pak-mount trial | A5098B8A1A8178BB84A8E131F8F71D39C3D32B496F4407392533DF82386CA08A |

The patch checks and changes only these bytes in the pristine file:

| File offset | Expected | Replacement |
| --- | --- | --- |
| 0x352DF54 (PE RVA 0x352E954) | 80 3D B5 1B 06 03 03 | EB F7 90 90 90 90 90 |
| 0x35394E8 (PE RVA 0x3539EE8) | 0F 84 83 07 00 00 | 90 90 90 90 90 90 |

The included .sig is the tested local-project CRC-table signature and is **not** a genuine publisher cryptographic signature. The patch is scoped to this local build. Do not use this add-on with a different build or an official online install.

## Uninstall

Close the game, then double-click **Uninstall-Karambit.bat** and select the same game root. Or run:

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<extracted add-on>\Uninstall-Karambit.ps1" -GameRoot "<folder containing Prospect>"

Uninstall restores only files and registration state owned by this installer. If another program changed an installed Karambit file, uninstall stops and preserves that change. If the game executable was updated afterward, uninstall preserves the newer executable while removing its owned add-on files. If these exact assets were already present before this installer ran, it reports them as *unmanaged* and does not create an uninstall claim.

## Compatibility and troubleshooting

- **Unknown executable SHA-256:** Obtain the tested Season 2 build you legitimately own. The installer will not guess or patch other bytes.
- **Different pakchunk99 already exists:** It may belong to another mod. The installer refuses to replace it unless you explicitly use -ReplaceExisting; the old file is then backed up.
- **UE4SS missing:** Your existing launcher must install/load UE4SS, including UE4SS.dll, xinput1_3.dll, and Mods\mods.txt. Loader and UE4SS hashes that differ from the tested copy produce warnings because a friend's launcher may supply another compatible build.
- **Error code 5 or no station:** Start the local API and game through your existing launcher. This add-on does not provide authentication, API endpoints, or a server.
- **No Karambit grip or sound:** Confirm KarambitPort : 1 in Mods\mods.txt, KarambitPort\enabled.txt, the four payload hashes in PackageManifest.json, and UE4SS logs. A game build other than the exact supported one is rejected before install.
- **Installer interrupted:** Close the game and rerun it. It validates the saved backup paths and hashes, restores the original state, and retries. Keep the backup folder if recovery reports an error.
